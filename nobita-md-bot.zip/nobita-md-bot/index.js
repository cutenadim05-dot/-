import 'dotenv/config';
import express from 'express';
import TelegramBot from 'node-telegram-bot-api';
import pino from 'pino';
import makeWASocket, {
  Browsers,
  DisconnectReason,
  fetchLatestBaileysVersion,
  useMultiFileAuthState
} from '@whiskeysockets/baileys';
import fs from 'node:fs';
import path from 'node:path';

const BOT_NAME = process.env.BOT_NAME || 'NOBITA MD BOT';
const PREFIX = process.env.PREFIX || '.';
const PORT = Number(process.env.PORT || 3000);
const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const TELEGRAM_ADMIN_ID = String(process.env.TELEGRAM_ADMIN_ID || '');
const logger = pino({ level: process.env.LOG_LEVEL || 'info' });

if (!TELEGRAM_BOT_TOKEN || !TELEGRAM_ADMIN_ID || TELEGRAM_ADMIN_ID === '123456789') {
  console.error('Set TELEGRAM_BOT_TOKEN and TELEGRAM_ADMIN_ID in hosting Environment Variables.');
  process.exit(1);
}

// Simple health endpoint for hosts that require an HTTP port.
const app = express();
let waStatus = 'starting';
let waSocket;
app.get('/', (_req, res) => res.status(200).json({ bot: BOT_NAME, status: 'online', whatsapp: waStatus }));
app.listen(PORT, '0.0.0.0', () => logger.info(`Health server listening on ${PORT}`));

const tg = new TelegramBot(TELEGRAM_BOT_TOKEN, { polling: true });
tg.on('polling_error', (err) => logger.warn({ err: err.message }, 'Telegram polling error'));
const isTelegramAdmin = (msg) => String(msg.from?.id || '') === TELEGRAM_ADMIN_ID;
const tgReply = (msg, text) => tg.sendMessage(msg.chat.id, text, { reply_to_message_id: msg.message_id });

let pairingRequested = false;
let reconnecting = false;
let lastQrOrPairingInfo = 'Not paired yet';
const authDir = path.resolve('auth_info_baileys');
fs.mkdirSync(authDir, { recursive: true });

async function startWhatsApp() {
  const { state, saveCreds } = await useMultiFileAuthState(authDir);
  let version;
  try { ({ version } = await fetchLatestBaileysVersion()); } catch { version = undefined; }

  waSocket = makeWASocket({
    version,
    logger,
    auth: state,
    browser: Browsers.ubuntu('NOBITA MD BOT'),
    printQRInTerminal: false,
    generateHighQualityLinkPreview: false,
    syncFullHistory: false
  });

  waSocket.ev.on('creds.update', saveCreds);
  waSocket.ev.on('connection.update', async ({ connection, lastDisconnect }) => {
    if (connection === 'connecting') waStatus = 'connecting';
    if (connection === 'open') {
      waStatus = 'connected';
      pairingRequested = false;
      lastQrOrPairingInfo = 'WhatsApp connected successfully';
      logger.info('WhatsApp connected');
      try { await tg.sendMessage(TELEGRAM_ADMIN_ID, `✅ ${BOT_NAME}: WhatsApp connected.`); } catch {}
    }
    if (connection === 'close') {
      waStatus = 'disconnected';
      const code = lastDisconnect?.error?.output?.statusCode;
      const loggedOut = code === DisconnectReason.loggedOut;
      logger.warn({ code, loggedOut }, 'WhatsApp connection closed');
      if (!loggedOut && !reconnecting) {
        reconnecting = true;
        setTimeout(() => startWhatsApp().catch(err => logger.error(err)), 3000);
      } else if (loggedOut) {
        lastQrOrPairingInfo = 'Logged out. Remove old session only if you intend to pair again.';
      }
    }
  });

  waSocket.ev.on('group-participants.update', async (event) => {
    try {
      const meta = await waSocket.groupMetadata(event.id);
      const groupName = meta.subject || 'the group';
      for (const participant of event.participants) {
        if (event.action === 'add') {
          await waSocket.sendMessage(event.id, {
            text: `╭─「 🌸 Welcome 」\n│ Welcome to *${groupName}*!\n│ @${participant.split('@')[0]}\n│ Please read the group rules.\n╰────────────`,
            mentions: [participant]
          });
        } else if (event.action === 'remove') {
          await waSocket.sendMessage(event.id, {
            text: `👋 Goodbye @${participant.split('@')[0]}. Take care!`,
            mentions: [participant]
          });
        }
      }
    } catch (err) { logger.warn({ err: err.message }, 'Welcome/goodbye handler failed'); }
  });

  waSocket.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return;
    for (const m of messages) {
      try { await handleWhatsAppMessage(m); }
      catch (err) { logger.warn({ err: err.message }, 'Message handler error'); }
    }
  });
  reconnecting = false;
}

function getText(m) {
  const msg = m.message || {};
  return msg.conversation || msg.extendedTextMessage?.text || msg.imageMessage?.caption || msg.videoMessage?.caption || '';
}
function jidNumber(jid = '') { return jid.split('@')[0].split(':')[0]; }
async function groupAdminCheck(m) {
  const jid = m.key.remoteJid;
  if (!jid?.endsWith('@g.us')) return { ok: false, reason: 'This command only works in groups.' };
  const meta = await waSocket.groupMetadata(jid);
  const sender = m.key.participant || m.key.remoteJid;
  const botJid = waSocket.user?.id?.split(':')[0] + '@s.whatsapp.net';
  const senderRow = meta.participants.find(p => p.id === sender || jidNumber(p.id) === jidNumber(sender));
  const botRow = meta.participants.find(p => jidNumber(p.id) === jidNumber(botJid));
  if (!senderRow?.admin) return { ok: false, reason: 'Only group admins can use this command.' };
  if (!botRow?.admin) return { ok: false, reason: 'Make the bot a group admin first.' };
  return { ok: true, meta, sender };
}
async function handleWhatsAppMessage(m) {
  if (!m.message || m.key.fromMe) return;
  const text = getText(m).trim();
  if (!text.startsWith(PREFIX)) return;
  const [rawCmd, ...args] = text.slice(PREFIX.length).trim().split(/\s+/);
  const cmd = (rawCmd || '').toLowerCase();
  const jid = m.key.remoteJid;
  const reply = (text) => waSocket.sendMessage(jid, { text }, { quoted: m });

  if (cmd === 'menu' || cmd === 'help') {
    return reply(`╭─「 𐏓꯭⸙ ${BOT_NAME} 」\n│ ${PREFIX}menu\n│ ${PREFIX}tagall — tag group members\n│ ${PREFIX}kick @member\n│ ${PREFIX}promote @member\n│ ${PREFIX}demote @member\n╰────────────\nAdmin commands require you and the bot to be group admins.`);
  }
  if (!['tagall', 'kick', 'promote', 'demote'].includes(cmd)) return;
  const check = await groupAdminCheck(m);
  if (!check.ok) return reply(`⛔ ${check.reason}`);
  const mentions = m.message.extendedTextMessage?.contextInfo?.mentionedJid || [];

  if (cmd === 'tagall') {
    const all = check.meta.participants.map(p => p.id).filter(id => id !== check.sender);
    const note = args.join(' ') || 'Attention everyone!';
    let body = `📢 *${note}*\n\n` + all.map(id => `• @${jidNumber(id)}`).join('\n');
    // Keep messages within WhatsApp's practical message-size limit.
    if (body.length > 3500) body = body.slice(0, 3400) + '\n…';
    return waSocket.sendMessage(jid, { text: body, mentions: all.slice(0, 100) }, { quoted: m });
  }
  if (!mentions.length) return reply(`Usage: ${PREFIX}${cmd} @member`);
  try {
    if (cmd === 'kick') await waSocket.groupParticipantsUpdate(jid, mentions, 'remove');
    if (cmd === 'promote') await waSocket.groupParticipantsUpdate(jid, mentions, 'promote');
    if (cmd === 'demote') await waSocket.groupParticipantsUpdate(jid, mentions, 'demote');
    return reply(`✅ ${cmd} request completed for ${mentions.length} member(s).`);
  } catch (err) { return reply(`❌ Command failed: ${err.message}`); }
}

// Telegram controls are restricted to the numeric Telegram user ID in TELEGRAM_ADMIN_ID.
tg.onText(/^\/start$/, async (msg) => {
  if (!isTelegramAdmin(msg)) return tgReply(msg, '⛔ Not authorized.');
  return tgReply(msg, `𐏓꯭⸙ ${BOT_NAME}\n\n/status - check status\n/pair 8801XXXXXXXXX - request WhatsApp pairing code\n/help - command help\n\nKeep your pairing code and tokens private.`);
});
tg.onText(/^\/help$/, async (msg) => {
  if (!isTelegramAdmin(msg)) return tgReply(msg, '⛔ Not authorized.');
  return tgReply(msg, '/status\n/pair 8801XXXXXXXXX\n/help');
});
tg.onText(/^\/status$/, async (msg) => {
  if (!isTelegramAdmin(msg)) return tgReply(msg, '⛔ Not authorized.');
  return tgReply(msg, `🤖 ${BOT_NAME}\nWhatsApp: ${waStatus}\nSession: ${lastQrOrPairingInfo}`);
});
tg.onText(/^\/pair(?:\s+([0-9]{10,15}))?$/, async (msg, match) => {
  if (!isTelegramAdmin(msg)) return tgReply(msg, '⛔ Not authorized.');
  const phone = match?.[1];
  if (!phone) return tgReply(msg, 'Send your number with country code, digits only. Example: /pair 8801XXXXXXXXX');
  if (waSocket?.user) return tgReply(msg, 'WhatsApp is already connected. Use /status.');
  if (!waSocket?.requestPairingCode) return tgReply(msg, 'WhatsApp socket is not ready yet. Wait a few seconds and retry.');
  try {
    pairingRequested = true;
    const code = await waSocket.requestPairingCode(phone);
    lastQrOrPairingInfo = `Pairing code requested at ${new Date().toISOString()}`;
    return tgReply(msg, `🔐 WhatsApp pairing code: ${code}\n\nOn your phone: WhatsApp → Linked devices → Link a device → Link with phone number instead. Enter the code.\n\nDo not share this code. It expires; request a new one if needed.`);
  } catch (err) {
    pairingRequested = false;
    logger.warn({ err: err.message }, 'Pairing code request failed');
    return tgReply(msg, `Could not get pairing code: ${err.message}\nWait a few seconds and try again.`);
  }
});

process.on('unhandledRejection', err => logger.error({ err }, 'Unhandled rejection'));
process.on('uncaughtException', err => logger.error({ err }, 'Uncaught exception'));

startWhatsApp().catch(err => {
  waStatus = 'error';
  logger.error({ err }, 'Could not start WhatsApp');
});
