# 𐏓꯭⸙ NOBITA MD BOT

WhatsApp bot with pairing-code login, group welcome/goodbye, admin commands, and Telegram status/pairing control.

## Files
- `index.js` — bot code
- `package.json` — dependencies/start script
- `.gitignore` — keeps credentials/session out of Git
- `.env.example` — example environment variables only
- `render.yaml` — Render web-service blueprint

## Environment variables
Set these in your hosting provider's dashboard, not in GitHub:
- `TELEGRAM_BOT_TOKEN`: token from Telegram's `@BotFather`
- `TELEGRAM_ADMIN_ID`: your numeric Telegram user ID
- `BOT_NAME`: optional, defaults to `NOBITA MD BOT`
- `PREFIX`: optional, defaults to `.`
- `PORT`: set by the host in most cases

## Telegram
- `/start`
- `/status`
- `/pair 8801XXXXXXXXX` — replace with your own number including country code, digits only

After the bot returns a pairing code, on the WhatsApp phone open **Settings → Linked devices → Link a device → Link with phone number instead** and enter the code. Menu wording may vary by WhatsApp version.

## WhatsApp group commands
- `.menu`
- `.tagall [message]`
- `.kick @member`
- `.promote @member`
- `.demote @member`

The sender and the bot must both be group admins for moderation commands. Use only in groups where you have permission.

## Deploy notes
GitHub stores code; it does not keep this bot running by itself. Deploy as a Node.js web service on a host that allows a persistent long-running process. Free services may sleep and their local filesystem may be erased on restart/redeploy. Baileys session files are stored in `auth_info_baileys/`; do not commit them. If your host does not provide persistent storage, you may need to pair again after a restart. A persistent disk is commonly a paid feature.

## Security
Never commit `.env`, Telegram bot tokens, WhatsApp auth files, or pairing codes. If a token was exposed, revoke it with BotFather and create a new one. Restrict Telegram control using `TELEGRAM_ADMIN_ID`.
